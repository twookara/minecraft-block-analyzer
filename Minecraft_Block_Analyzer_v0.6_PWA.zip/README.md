# Minecraft Block Analyzer v0.6 (PWA)

## 追加点
- PWA対応
- iPhoneのSafariから「ホーム画面に追加」でアプリ風に起動可能
- manifest / Service Worker / アプリアイコンを追加
- 一度読み込んだ後は主要ファイルをキャッシュし、オフライン起動に対応
- v0.5までの自動四隅検出、手動補正、ズーム、16×16生成、色解析、画像表示/共有を維持

## iPhoneに入れる方法
このZIPをHTTPS対応のWebホスティングへ配置してください。
1. Safariで配置先URLを開く
2. 共有ボタン
3. 「ホーム画面に追加」
4. ホーム画面の Block Analyzer を起動

## 重要
ローカルファイルを直接開くだけではPWAとしてインストールできません。
HTTPS配信が必要です（localhostは例外）。
